
<link rel="stylesheet" href="<?php echo e(asset('css/Userdashboard.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/admindashboard.css')); ?>">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script src="//code.jquery.com/jquery-2.1.4.min.js"></script> 
<script src="<?php echo e(asset('js/GaugeMeter.js')); ?>"></script> 
<script src="<?php echo e(asset('js/userdashboard.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.are-you-sure.js')); ?>"></script> 
<script>
    $( document ).ready(function() {
        $('form.dirty-check').areYouSure();
});
    setTimeout(function() {
    $('.hidecroosss').fadeOut('slow');
}, 5000); 
</script>
<?php if($showallrooms == 1): ?>
    <script>
        $(document).ready(function(){
        $("#mainwindow").removeClass("active1");
        $("#controls").addClass("active1");
        $("#mainwindowbutton").removeClass("active");
        $("#controlsbutton").addClass("active");
        });
    </script>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div class="row maindiv">
    <!--***********TABS MAIN DIV***********-->
    <div class="tab-div col-lg-2 col-sm-3 col-md-3">
        <div class="logoDiv">
            <a href="<?php echo e(url('/')); ?>">
            <h3 style="color: white">HomeHaven - <span style="font-size: 15px"> Admin</span></h3>
            </a>
        </div>

        <div class="userInfo">
            <img 
            <?php if(Auth::user()->image_name == null): ?>{
            src="<?php echo e(asset('images/user.png')); ?>"
             }
            <?php else: ?>{
                <?php
                    $image = Auth::user()->image_name;
                ?>
                src="<?php echo asset("storage/$image")?>"
            }
            <?php endif; ?> 
            width="80" height="80" alt="user">
            <p>Hello,</p>
            <h3><?php echo e(Auth::user()->name); ?></h3>
        </div>

        <div class="menus">
            <h4>Dashboard</h4>
            <button onclick="openCity(event, 'mainwindow')" id="mainwindowbutton" class="tablinks active"><i class="fas fa-tachometer-alt"></i>&nbsp; Manage Users</button><br>
            <button onclick="openCity(event, 'controls')" id="controlsbutton" class="tablinks"><i class="fas fa-dharmachakra"></i></i>&nbsp; Manage Rooms</button><br>
            <button onclick="openCity(event, 'nightmode')" class="tablinks"><i class="fas fa-moon"></i></i>&nbsp; Night Mode</button><br>
            <button onclick="openCity(event, 'settings')" class="tablinks"><i class="fa fa-wrench"></i>&nbsp; Settings</button><br>
            <button href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i>&nbsp; Sign Out</button>
        </div>
    </div>

    <!--***********CONTENT MAIN DIV***********-->
    <div class="content-div col-lg-10 col-sm-9 col-xs-12 col-md-9">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger hidecroosss">
                            Name is Invalid.
        </div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger hidecroosss">
                The email has already been taken.
            </div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
         <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger hidecroosss">
                The password confirmation does not match.
            </div>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if(session('success')): ?>
                            <div style="margin-top: 10px" class="alert alert-success hidecroosss">
                                <?php echo e(session('success')); ?>

                            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
                        <div class="alert alert-danger hidecroosss">
                            <?php echo e(session('error')); ?>

                        </div>
        <?php endif; ?>
 

        <!--MAIN WINDOW TAB-->
        <div style="padding: 10px" class="tabcontent active1" id="mainwindow" >

        <div class="activeusersmain">
            <div class="row" style="width: 100%;">
            <div class="col-md-4 form-group">
                <form action="/searchuser" method="post" class="navbar-form" role="search">
                    <?php echo csrf_field(); ?>
                    <div class="form-group input-group col-md-12">
                        <input type="text" class="form-control" placeholder="Search users" name="name">
                        <div class="input-group-btn">
                            <button style="background-color: #79abfa; padding: 10px; border-radius: 0px 10px 10px 0px;" 
                            class="btn btn-default" type="submit"><i style="padding: 0px 10px; color:white;" class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-md-3">
                <?php if($showallusers == 1): ?>
                <p><a class="btn btn-secondary" href="/">Show All Users</a></p>
                <?php endif; ?>
                <p><a class="btn btn-primary" href="#popupnew">Create New Account</a></p>
            </div>


            <div id="popupnew" class="overlay11 light11">
	            <a class="cancel" href="#"></a>
	            <div class="popup">
                    <h2>Edit user</h2>
                    <a class="close" href="#">&times;</a>
		            <div class="content">
                    <?php
                    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
                    $pass = array(); //remember to declare $pass as an array
                    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
                    for ($i = 0; $i < 8; $i++) {
                        $n = rand(0, $alphaLength);
                        $pass[] = $alphabet[$n];
                    }
                    $pass = implode($pass); //turn the array into a string
                    ?>

                    <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control is-valid" value="<?php echo e($pass); ?>" name="password" required autocomplete="new-password" readonly>
                                    <span class="valid-feedback">
                                        <strong>Password is auto-generated and will be sent to user through email.</strong>
                                    </span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" value="<?php echo e($pass); ?>" required autocomplete="new-password" readonly>
                            </div>
                            <input type="text" name="role" value="user" hidden>
                            <input type="text" name="status" value="active" hidden>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>


		            </div>
	            </div>
            </div>
            </div>

            <div class="activeusers">
                <h3 style="font-size: 23px; font-weight: 300">Users</h3>
                <?php if($users_active == null): ?>
                <h2 style="font-weight: 300">No User Found</h2>
                <?php else: ?>
                <table class="table">
                    <thead class="thead-light ">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>    
                        <th>Status</th>
                        <th>Created on</th>
                        <th></th>
                    </tr>
                    </thead>    

                    <tbody>
                        <?php $__currentLoopData = $users_active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                            $new_date = date("d-m-Y",strtotime($user->created_at));
                            ?>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->status); ?></td>
                            <td><?php echo e($new_date); ?></td>
                            <td><p><a class="button11" href="#popup<?php echo e($user->id); ?>">Edit</a></p></td>

                            <div id="popup<?php echo e($user->id); ?>" class="overlay11 light11">
	                            <a class="cancel" href="#"></a>
	                            <div class="popup">
                                    <h2>Edit user</h2>
                                    <a class="close" href="#">&times;</a>
                                    <div class="content">

                                    <form action="/updateuser" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" name="id" value="<?php echo e($user->id); ?>" hidden>
                                      <label for="name">Name: </label>
                                      <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" value="<?php echo e($user->name); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <label for="email">Email: </label>
                                      <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email" value="<?php echo e($user->email); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <label for="status">Status: </label>
                                      <select class="form-control" name="status">
                                        <?php if($user->status == "active"): ?>
                                        <option value="active" selected>Active</option>
                                        <option value="disabled">Disabled</option>
                                        <?php else: ?>  
                                        <option value="active">Active</option>
                                        <option value="disabled" selected>Disabled</option>  
                                        <?php endif; ?>
                                      </select> 

                                      <button style="margin-top: 10px; float: right" class="btn btn-primary" type="submit">Save</button>
                                    </form>
                                      
                                      <form onsubmit="return confirm('All the data of this user will be deleted. Do you really want to delete this user?');" action="/deleteuser/<?php echo e($user->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button value="confirm" style="margin-top: 10px; float: left" class="btn btn-danger" type="submit">Delete User</button>
                                      </form>
                                      </div>
		                            </div>
	                            </div>
                            </div>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                </table>
                <?php echo e($users_active->links()); ?>

                <?php endif; ?>
            </div>


        </div>
            
        </div>

        <!--************************************************************-->
        <!--*********************MANAGE ROOMS TAB***********************-->
        <!--************************************************************-->

        <div id="controls" style="overflow-x: hidden; overflow-y:auto; max-height: 100%;" class="tabcontent controlsdiv">
            
            <div class="activeusersmain">
            <div class="row" style="width: 100%;">
            <div class="col-md-4 form-group">
                <form action="/searchuserbyid" method="post" class="navbar-form" role="search">
                    <?php echo csrf_field(); ?>
                    <div class="form-group input-group col-md-12">
                        <input type="number" class="form-control" placeholder="Search Rooms by User ID" name="id" required>
                        <div class="input-group-btn">
                            <button style="background-color: #79abfa; padding: 10px; border-radius: 0px 10px 10px 0px;" 
                            class="btn btn-default" type="submit"><i style="padding: 0px 10px; color:white;" class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-md-3">
                <?php if($showallrooms == 1): ?>
                <p><a class="btn btn-secondary" href="/">Show All Users</a></p>
                <?php endif; ?>
                <p><a class="btn btn-primary" href="#popupnew1">Add New Room</a></p>
            </div>
            <div id="popupnew1" class="overlay11 light11">
	            <a class="cancel" href="#"></a>
	            <div style="height: 535px" class="popup">
                    <h2>Add Room</h2>
                    <a class="close" href="#">&times;</a>
		            <div class="content">

                    <form method="POST" action="/addnewroom">
                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                            <label for="user_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('User ID')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="user_id">
                                    <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value= <?php echo e($user->id); ?> selected><?php echo e($user->id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__(' Room Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="desc" class="col-md-4 col-form-label text-md-right"><?php echo e(__(' Description(Optional)')); ?></label>

                            <div class="col-md-6">
                                <input id="desc" type="text" class="form-control" name="desc">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="dev1" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Device 1')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="dev1">
                                    <option value= 0 selected>None</option>
                                    <option value= 1>Light</option>
                                    <option value= 2>Fan</option>
                                    <option value= 3>Socket</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="dev2" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Device 2')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="dev2">
                                    <option value= 0 selected>None</option>
                                    <option value= 1>Light</option>
                                    <option value= 2>Fan</option>
                                    <option value= 3>Socket</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="dev3" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Device 3')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="dev3">
                                    <option value= 0 selected>None</option>
                                    <option value= 1>Light</option>
                                    <option value= 2>Fan</option>
                                    <option value= 3>Socket</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="dev4" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Device 4')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="dev4">
                                    <option value= 0 selected>None</option>
                                    <option value= 1>Light</option>
                                    <option value= 2>Fan</option>
                                    <option value= 3>Socket</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="devdim" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Dimable Device')); ?></label>

                            <div class="col-md-6">
                                <select class="form-control" name="devdim">
                                    <option value= 0 selected>None</option>
                                    <option value= 1>Light</option>
                                    <option value= 2>Fan</option>
                                    <option value= 3>Socket</option>
                                </select>
                            </div>
                        </div>
                            

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Add Room')); ?>

                                </button>
                            </div>
                        </div>
                    </form>


		            </div>
	            </div>
            </div>
            </div>

            <div class="activeusers">
                <h3 style="font-size: 23px; font-weight: 300">Rooms</h3>
                <?php if($user_rooms == null): ?>
                <h2 style="font-weight: 300">No Rooms Found</h2>
                <?php else: ?>
                <table class="table">
                    <thead class="thead-light ">
                    <tr>
                        <th>User ID</th>
                        <th>Room</th>
                        <th>Device 1</th>
                        <th>Device 2</th>    
                        <th>Device 3</th>
                        <th>Device 4</th>
                        <th>Dimable Device</th>
                    </tr>
                    </thead>    

                    <tbody>
                        <?php $__currentLoopData = $user_rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if($room->dev1_type == 1)
                        {
                            $room->dev1_type = 'Light';
                        }
                        elseif ($room->dev1_type == 2)
                        {
                            $room->dev1_type = 'Fan';
                        }
                        elseif ($room->dev1_type == 3)
                        {
                            $room->dev1_type = 'Socket';
                        }
                        else {
                            $room->dev1_type = 'None';
                        }


                        if($room->dev2_type == 1)
                        {
                            $room->dev2_type = 'Light';
                        }
                        elseif ($room->dev2_type == 2)
                        {
                            $room->dev2_type = 'Fan';
                        }
                        elseif ($room->dev2_type == 3)
                        {
                            $room->dev2_type = 'Socket';
                        }
                        else {
                            $room->dev2_type = 'None';
                        }


                        if($room->dev3_type == 1)
                        {
                            $room->dev3_type = 'Light';
                        }
                        elseif ($room->dev3_type == 2)
                        {
                            $room->dev3_type = 'Fan';
                        }
                        elseif ($room->dev3_type == 3)
                        {
                            $room->dev3_type = 'Socket';
                        }
                        else {
                            $room->dev3_type = 'None';
                        }


                        if($room->dev4_type == 1)
                        {
                            $room->dev4_type = 'Light';
                        }
                        elseif ($room->dev4_type == 2)
                        {
                            $room->dev4_type = 'Fan';
                        }
                        elseif ($room->dev4_type == 3)
                        {
                            $room->dev4_type = 'Socket';
                        }
                        else {
                            $room->dev4_type = 'None';
                        }


                        if($room->dim_type == 1)
                        {
                            $room->dim_type = 'Light';
                        }
                        elseif ($room->dim_type == 2)
                        {
                            $room->dim_type = 'Fan';
                        }
                        elseif ($room->dim_type == 3)
                        {
                            $room->dim_type = 'Socket';
                        }
                        else {
                            $room->dim_type = 'None';
                        }
                        ?>
                        <tr>
                            <td><?php echo e($room->user_id); ?></td>
                            <td><?php echo e($room->name); ?></td>
                            <td><?php echo e($room->dev1_type); ?></td>
                            <td><?php echo e($room->dev2_type); ?></td>
                            <td><?php echo e($room->dev3_type); ?></td>
                            <td><?php echo e($room->dev4_type); ?></td>
                            <td><?php echo e($room->dim_type); ?></td>
                            <td><p><a class="button11" href="#popuproom<?php echo e($room->id); ?>">Edit</a></p></td>

                            <div id="popuproom<?php echo e($room->id); ?>" class="overlay11 light11">
	                            <a class="cancel" href="#"></a>
	                            <div class="popup popuproom">
                                    <h2>Edit Room</h2>
                                    <a class="close" href="#">&times;</a>
                                    <div class="content">

                                    <form action="/updateroom" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="number" name="id" value="<?php echo e($room->id); ?>" hidden>
                                      <label for="name">Name: </label>
                                      <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" value="<?php echo e($room->name); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                      <label for="dev1">Device 1: </label>
                                      <select class="form-control" name="dev1">
                                        <?php if($room->dev1_type == 'Light'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1 selected>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev1_type == 'Fan'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2 selected>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev1_type == 'Socket'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3 selected>Socket</option>
                                        <?php else: ?>  
                                        <option value= 0 selected>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php endif; ?>
                                      </select> 

                                      <label for="dev2">Device 2: </label>
                                      <select class="form-control" name="dev2">
                                        <?php if($room->dev2_type == 'Light'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1 selected>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev2_type == 'Fan'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2 selected>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev2_type == 'Socket'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3 selected>Socket</option>
                                        <?php else: ?>  
                                        <option value= 0 selected>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php endif; ?>
                                      </select> 

                                      <label for="dev3">Device 3: </label>
                                      <select class="form-control" name="dev3">
                                        <?php if($room->dev3_type == 'Light'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1 selected>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev3_type == 'Fan'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2 selected>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev3_type == 'Socket'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3 selected>Socket</option>
                                        <?php else: ?>  
                                        <option value= 0 selected>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php endif; ?>
                                      </select> 

                                      <label for="dev4">Device 4: </label>
                                      <select class="form-control" name="dev4">
                                        <?php if($room->dev4_type == 'Light'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1 selected>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev4_type == 'Fan'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2 selected>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dev4_type == 'Socket'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3 selected>Socket</option>
                                        <?php else: ?>  
                                        <option value= 0 selected>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php endif; ?>
                                      </select> 

                                      <label for="devdim">Device 4: </label>
                                      <select class="form-control" name="devdim">
                                        <?php if($room->dim_type == 'Light'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1 selected>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dim_type == 'Fan'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2 selected>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php elseif($room->dim_type == 'Socket'): ?>
                                        <option value= 0>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3 selected>Socket</option>
                                        <?php else: ?>  
                                        <option value= 0 selected>None</option>
                                        <option value= 1>Light</option>
                                        <option value= 2>Fan</option>
                                        <option value= 3>Socket</option>
                                        <?php endif; ?>
                                      </select> 



                                      <button style="margin-top: 10px; float: right" class="btn btn-primary" type="submit">Update Room</button>
                                    </form>
                                      
                                      <form onsubmit="return confirm('Do you realy want to delete this room?');" action="/deleteroom" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="number" value="<?php echo e($room->id); ?>" hidden name="room_id">
                                        <button value="confirm" style="margin-top: 10px; float: left" class="btn btn-danger" type="submit">Delete Room</button>
                                      </form>
                                      </div>
		                            </div>
	                            </div>
                            </div>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </tbody>
                </table>
                <?php echo e($user_rooms->links()); ?>

                <?php endif; ?>
            </div>
        </div>

         <!--*********************NIGHTMODE MAIN TAB***********************-->
         <div id="nightmode" style="overflow-x: hidden; overflow-y:auto; max-height: 100%;" class="tabcontent nightmodemain">
            <h1>Content 3</h1>
         </div>


        <!--*****************SETTINGS TAB****************-->
        <div id="settings" class="tabcontent settingstab col-md-8 col-lg-6 col-sm-12 col-xs-12">
            <div class="editdp settingcontent">
            <form action="/saveuserimage" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <img id="uploadeddp"
            <?php if(Auth::user()->image_name == null): ?>{
            src="<?php echo e(asset('images/user.png')); ?>"
             }
            <?php else: ?>{
                <?php
                    $image = Auth::user()->image_name;
                ?>
                src="<?php echo asset("storage/$image")?>"
            }
            <?php endif; ?> 
            alt="user">
                 
                <input type="file" class="choosedp" accept="image/*" name="dpimg" id="dpfile">
                <label class="dpbutton" for="dpfile">Change Image</label>
                <button style="margin-top: 10px; float: right; background-color: #2779ff" type="submit" class="btn btn-success" disabled>Save Image</button>
            </form>
            </div>

            <div class="settingcontent editemail">
                <label for="emailid">Email: </label>
                <input type="email" class="form-control" name="email" id="emailid" value="<?php echo e(Auth::user()->email); ?>" readonly>
                <label style="margin-top: 10px" onclick="window.location='<?php echo e(url("changeEmail")); ?>'" class="dpbutton">Change Email</label>
            </div>

            <div class="settingcontent editpassword">
                <label>Password: <span style="color:#858585;">&nbsp;***********</span></label>
                <label onclick="window.location='<?php echo e(url("changePassword")); ?>'" class="dpbutton editpasswordbutton">Change Password</label>
            </div>
            <div class="settingcontent">
               
            </div>
        </div>
    </div>
</div>
<script>

/*UPLOAD IMAGE-DP*/
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
reader.onload = function(e) {
  $('#uploadeddp').attr('src', e.target.result);
}
reader.readAsDataURL(input.files[0]); // convert to base64 string
}
}
$("#dpfile").change(function() {
readURL(this);
});

/*CHECK IF INPUT IS EMPTY*/
$('input[type=file]').change(function(){
    if($('input[type=file]').val()==''){
        $('button').attr('disabled',true)
    } 
    else{
      $('button').attr('disabled',false);
    }
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mylayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\homehaven\resources\views/admindashboard.blade.php ENDPATH**/ ?>