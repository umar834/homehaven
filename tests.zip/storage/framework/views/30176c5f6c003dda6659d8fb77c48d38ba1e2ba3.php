<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=s, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'HomeHaven')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/img/favicon.png')); ?>" />
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\homehaven\resources\views/layouts/mylayout.blade.php ENDPATH**/ ?>